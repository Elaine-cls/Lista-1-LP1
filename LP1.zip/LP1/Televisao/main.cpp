#include <iostream>
#include "Televisao.h"

using namespace std;

int main()
{
    Televisao tv = Televisao(200, 300);

    cout << "Canal:" << tv.getCanal() << endl;

    tv.incrementaCanal();

    cout << "Canal:" << tv.getCanal() << endl;

    cout << "Volume:" << tv.getVolume() << endl;

    tv.incrementaVolume();

    cout << "Volume:" << tv.getVolume() << endl;
    return 0;
}
