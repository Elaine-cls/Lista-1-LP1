#ifndef CONTROLEDEPAGAMENTO_H
#define CONTROLEDEPAGAMENTO_H
#include "Pagamento.h"


class ControleDePagamento
{
    private:
        Pagamento pagamentos [50];
        int iAtual;


    public:
        ControleDePagamento();
        void addPagamento(Pagamento p);
        double calculaTotalDePagamentos();
        bool existePagamentoParaFuncionario  (std::string nomeFuncionario);




};

#endif // CONTROLEDEPAGAMENTO_H
