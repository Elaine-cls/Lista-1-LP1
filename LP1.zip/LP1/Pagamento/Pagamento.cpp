#include "Pagamento.h"

Pagamento::Pagamento(double v, std::string n)
{
    valorPagamento = v;
    nomeDoFuncionario = n;
}
Pagamento::Pagamento(){
}

void Pagamento::setValorPagamento(double v)
{
    valorPagamento = v;
}
double Pagamento::getValorPagamento()
{
    return valorPagamento;
}

void Pagamento::setNomeDoFuncionario(std::string n)
{
   nomeDoFuncionario = n;
}
std::string Pagamento::getNomeDoFuncionario()
{
    return nomeDoFuncionario;
}


