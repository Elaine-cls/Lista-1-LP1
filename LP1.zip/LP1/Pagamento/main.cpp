#include <iostream>
#include "ControleDePagamento.h"

using namespace std;

int main()
{

    Pagamento p1 = Pagamento(10, "Eu");

    ControleDePagamento cp = ControleDePagamento();
    cp.addPagamento(p1);

    cout << "Total Pag: " <<cp.calculaTotalDePagamentos() << endl;
    cout << "Existe Eu?: " <<cp.existePagamentoParaFuncionario("Eu") << endl;

    return 0;
}

