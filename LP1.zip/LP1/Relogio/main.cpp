#include <iostream>
#include "Relogio.h"

using namespace std;

int main()
{


        Relogio h1 = Relogio(23, 59, 01);

    cout << "Horario:" << h1.getHora() << ":" << h1.getMinuto() << ":" << h1.getSegundo() << endl;
    h1.avancarHorario();
    cout << "Horario:" << h1.getHora() << ":" << h1.getMinuto() << ":" << h1.getSegundo() << endl;

    return 0;
}
