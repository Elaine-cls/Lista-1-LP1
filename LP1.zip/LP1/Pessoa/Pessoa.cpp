#include "Pessoa.h"

Pessoa::Pessoa1(std::string n){
    nome = n;
}
Pessoa::Pessoa2(std::string n, int id, int tel)

{
    nome = n;
    idade = id;
    telefone = tel;
}

void Pessoa::setNome(std::string n){
    nome = n;
}
std::string Pessoa::getNome(){
    return nome;
}

void Pessoa::setIdade(int id){
    idade = id;
}

int Pessoa::getIdade(){
    return idade;
}
void Pessoa::setTelefone(int tel){
    telefone = tel;
}

int Pessoa::getTelefone(){
    return telefone;
}



